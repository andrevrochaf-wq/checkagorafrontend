import { X, CheckIcon } from 'lucide-react';

type AppointmentStatus = 'pending' | 'rescheduled' | 'canceled' | 'completed';

interface AppointmentCardProps {
  status: AppointmentStatus;
}

export function ScheduleConsultationCard({ status }: AppointmentCardProps) {
  const statusConfig = {
    pending: {
      label: 'Pendente',
      bgColor: 'bg-amber-100',
      textColor: 'text-amber-800',
      showActions: true,
    },
    rescheduled: {
      label: 'Reagendado',
      bgColor: 'bg-blue-100',
      textColor: 'text-blue-800',
      showActions: true,
    },
    canceled: {
      label: 'Cancelado',
      bgColor: 'bg-red-100',
      textColor: 'text-red-800',
      showActions: false,
    },
    completed: {
      label: 'Concluído',
      bgColor: 'bg-green-100',
      textColor: 'text-green-800',
      showActions: false,
    },
  };

  const current = statusConfig[status];

  return (
    <div className="relative flex flex-col justify-between p-4 md:p-6 bg-amber-50 rounded-xl w-full min-h-[200px] md:min-h-[300px] shadow-md">

      {/* Status badge */}
      <div className={`absolute top-4 right-4 ${current.bgColor} ${current.textColor} flex items-center justify-center text-xs md:text-sm font-semibold px-3 py-1 rounded shadow-md`}>
        {current.label}
      </div>

      {/* Patient info */}
      <div className="flex flex-col gap-1 w-full text-sm md:text-base">
        <h2 className="text-lg md:text-xl font-bold text-gray-800">João da Silva</h2>
        <p className="text-gray-700">CPF: 123.456.789-00</p>
        <p className="text-gray-700">Especialidade: Dentista</p>
        <p className="text-gray-700">Data: 10/10/2100</p>
        <p className="text-gray-700">Hora: 14:30</p>
        <p className="text-gray-700">Cidade: Natal</p>
        <p className="text-gray-700">Bairro: Lagoa nova</p>
      </div>

      {/* Action buttons */}
      {current.showActions && (
        <div className="flex flex-col-reverse md:flex-row items-center gap-2 md:gap-4 w-full mt-4">
          {/* Cancel button */}
          <button
            className="flex items-center justify-center gap-2 w-full px-4 py-2 md:py-3 rounded-xl text-sm md:text-lg font-medium transition shadow bg-[var(--color-error)] text-[var(--color-surface)] hover:bg-[var(--color-error-dark)] cursor-pointer"
          >
            <X />
            Cancelar
          </button>

          {/* Reschedule button */}
          <button
            className="flex items-center justify-center gap-2 w-full px-4 py-2 md:py-3 rounded-xl text-sm md:text-lg font-medium transition shadow bg-[var(--color-warning)] text-[var(--color-surface)] hover:bg-[var(--color-warning-dark)] cursor-pointer"
          >
            <CheckIcon />
            Reagendar
          </button>
        </div>
      )}
    </div>
  );
}
