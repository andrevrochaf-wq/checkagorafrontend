'use client';

import { ChevronUp, ChevronDown } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import {HeaderLink} from './HeaderLink';

interface DropdownMenuItem {
  label: string;
  href?: string;
  icon?: React.ReactNode;
  children?: DropdownMenuItem[];
}

interface DropdownMenuProps {
  label: string;
  icon?: React.ReactNode;
  items: DropdownMenuItem[];
  basePaths?: string[];
  depth?: number;
  onItemClick?: () => void;
  headerOpen?: boolean; // NOVO
}

export function DropdownMenu({
  label,
  icon,
  items,
  basePaths = [],
  depth = 0,
  onItemClick,
  headerOpen = true, // padrão: header aberto
}: DropdownMenuProps) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  const isActive =
    basePaths.includes(pathname) || items.some((item) => pathname === item.href);

  const toggle = () => setOpen((prev) => !prev);

  // Se o header for fechado, fecha o dropdown também
  useEffect(() => {
    if (!headerOpen) {
      setOpen(false);
    }
  }, [headerOpen]);

  return (
    <div className="w-full">
      <button
        onClick={toggle}
        className={`flex items-center px-3 gap-2 font-bold w-full ${
          isActive
            ? 'bg-[var(--color-primary-dark)] text-[var(--color-surface)] px-3 py-1 rounded-lg'
            : 'text-[var(--color-text)] hover:text-[var(--color-surface)] hover:bg-[var(--color-primary-dark)] px-3 py-1 rounded-lg'
        }`}
      >
        {icon}
        {label}
        {open ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
      </button>

      {open && (
        <div className="mt-1 ml-2 flex flex-col gap-2">
          {items.map((item) => {
            const hasChildren = item.children && item.children.length > 0;
            const isItemActive = pathname === item.href;

            return (
              <div key={item.label}>
                {item.href && !hasChildren && (
                  <HeaderLink
                    href={item.href}
                    icon={item.icon}
                    onClick={onItemClick}
                  >
                    {item.label}
                  </HeaderLink>
                )}

                {hasChildren && item.children && (
                  <DropdownMenu
                    label={item.label}
                    items={item.children}
                    depth={depth + 1}
                    onItemClick={onItemClick}
                    headerOpen={headerOpen}
                  />
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
