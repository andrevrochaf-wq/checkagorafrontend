'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Menu, X, CalendarCheck, FilePlus, Search, Settings, User, SquareUser, LogIn, UserPlus } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import Image from 'next/image';
import { useAuth } from '@/contexts/AuthContext';
import { DropdownMenu } from './DropdownMenu';
import { HeaderLink } from './HeaderLink';

export function Header() {
  const { user, loading } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  const headerRef = useRef<HTMLElement | null>(null);
  const pathname = usePathname();

  const closeMenu = () => {
    requestAnimationFrame(() => setMenuOpen(false));
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Node | null;
      if (headerRef.current && target && !headerRef.current.contains(target)) {
        setMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const isActive = (path: string) =>
    pathname === path
      ? 'bg-[var(--color-primary-dark)] text-[var(--color-surface)] px-3 py-1 rounded-lg'
      : 'text-[var(--color-text)] hover:text-[var(--color-surface)] hover:bg-[var(--color-primary-dark)] px-3 py-1 rounded-lg';

  if (loading) return null;

  return (
    <header
      ref={headerRef}
      className={`fixed top-0 left-0 w-full z-20 transition-all duration-300
        bg-[var(--color-surface)] ${menuOpen ? '' : 'shadow'}`}
    >
      <div className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-4 text-xl sm:text-2xl font-bold text-[var(--color-text)]">
            <Image
              src="/logo.png"
              alt="logo"
              width={100}
              height={100}
              className="w-12 h-12"
              priority
            />
            <h1>
              CheckAgora <span className="text-sm font-bold">Alivyx</span>
            </h1>
          </div>

          {/* Menu desktop */}
          <nav className="hidden md:flex space-x-2 items-center">
            {user ? (
              <>
                <HeaderLink href="/" icon={<CalendarCheck size={18} />} onClick={closeMenu}>
                  Inicio
                </HeaderLink>
                <HeaderLink href="/agendarConsulta" icon={<FilePlus size={18} />} onClick={closeMenu}>
                  Agendar Consulta
                </HeaderLink>
                <HeaderLink href="/agendarExame" icon={<FilePlus size={18} />} onClick={closeMenu}>
                  Agendar Exame
                </HeaderLink>
                <HeaderLink href="/verificarConsulta" icon={<Search size={18} />} onClick={closeMenu}>
                  Verificar
                </HeaderLink>
                <HeaderLink href={['/configuracoes/conta', '/configuracoes/perfil']} icon={<Settings size={18} />} onClick={closeMenu}>
                  Configurações
                </HeaderLink>
              </>
            ) : (
              <>
                <HeaderLink href="/login" icon={<LogIn />} onClick={closeMenu}>
                  Login
                </HeaderLink>
                <HeaderLink href="/cadastro" icon={<UserPlus />} onClick={closeMenu}>
                  Cadastro
                </HeaderLink>
              </>
            )}
          </nav>

          {/* Toggle menu mobile */}
          <button
            className="md:hidden text-[var(--color-text)] cursor-pointer"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Menu mobile */}
      <div
        className={`md:hidden overflow-hidden transition-all duration-300 ease-in-out
          ${menuOpen ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0'}
          bg-[var(--color-surface)] shadow`}
      >
        <div className="flex flex-col p-4 space-y-1">
          {user ? (
            <>
              <HeaderLink href="/" icon={<CalendarCheck size={20} />} onClick={closeMenu}>
                Inicio
              </HeaderLink>
              <DropdownMenu
                label="Agendar"
                icon={<FilePlus size={20} />}
                headerOpen={menuOpen}
                onItemClick={closeMenu}
                items={[
                  {
                    label: 'Consulta', icon: <FilePlus size={18} />, href: '/agendarConsulta'
                  },
                  {
                    label: 'Exame', icon: <FilePlus size={18} />, href: '/agendarExame'
                  },
                  {
                    label: 'Verificar', icon: <Search size={18} />, href: '/verificarConsulta'
                  }]}
              />

              <DropdownMenu
                label="Configurações"
                icon={<Settings size={20} />}
                headerOpen={menuOpen}
                onItemClick={closeMenu}
                items={[
                  {
                    label: 'Conta', icon: <User size={18} />, href: '/configuracoes/conta'
                  },
                  {
                    label: 'Perfil', icon: <SquareUser size={18} />, href: '/configuracoes/perfil'
                  }
                ]}
              />
            </>
          ) : (
            <>
              <HeaderLink href="/login" icon={<LogIn />} onClick={closeMenu}>
                Login
              </HeaderLink>
              <HeaderLink href="/cadastro" icon={<UserPlus />} onClick={closeMenu}>
                Cadastro
              </HeaderLink>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
