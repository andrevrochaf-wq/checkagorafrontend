import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ReactNode } from 'react';

interface HeaderLinkProps {
  href: string | string[]; // <- Aceita string ou array
  icon?: ReactNode;
  children: ReactNode;
  onClick?: () => void;
}

export function HeaderLink({ href, icon, children, onClick }: HeaderLinkProps) {
  const pathname = usePathname();

  // Garante que href seja um array
  const hrefs = Array.isArray(href) ? href : [href];

  // Verifica se algum dos caminhos bate com o pathname
  const isActive = hrefs.some((h) => pathname === h || pathname.startsWith(h + '/'));

  return (
    <Link
      href={Array.isArray(href) ? href[0] : href} // Usa o primeiro path como link real
      onClick={onClick}
      className={`flex items-center gap-2 font-bold px-3 py-1 whitespace-nowrap rounded-lg
        ${isActive
          ? 'bg-[var(--color-primary-dark)] text-[var(--color-surface)]'
          : 'text-[var(--color-text)] hover:text-[var(--color-surface)] hover:bg-[var(--color-primary-dark)]'}
      `}
    >
      {icon}
      <span className="flex-1 text-left">{children}</span>
    </Link>
  );
}
