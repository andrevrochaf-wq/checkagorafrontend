'use client';

import { X, CheckIcon } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import Loading from '@/components/Loading';

export default function AgendarExame() {

  const router = useRouter();
  const { user, loading } = useAuth();

  useEffect(() => {
    
    // Verifica se o carregamento está completo e o usuário não está logado
    if (!loading && !user) {
      router.push('/login');
    }
  }, [user, loading, router]);

  const navigateToHome = () => {
    router.push("/");
    
  };

  if (loading) return <Loading/>;
  if (!user) return null; // Garante que a página não será renderizada até redirecionar

    return (
        <div className="flex flex-col items-center pt-16 min-h-screen px-4 py-8">
        <h1 className="text-2xl font-bold mt-4">Agendar exame</h1>
  
        <div className="flex flex-col max-w-md w-full mt-4 space-y-4 text-[var(--color-text)]">
          <div className="flex flex-col space-y-1">
            <label htmlFor="cpf" className="font-bold">CPF</label>
            <input
              id="cpf"
              type="text"
              placeholder="Digite seu CPF"
              className="p-2 border-0 rounded-xl bg-amber-50"
            />
          </div>
  
          <div className="flex flex-col space-y-1">
            <label htmlFor="estado" className="font-bold">Estado</label>
            <select id="estado" className="p-2 border-0 rounded-xl bg-amber-50">
              <option value="">Selecione o estado</option>
              <option value="RN">RN</option>
            </select>
          </div>

          <div className="flex flex-col space-y-1">
            <label htmlFor="cidade" className="font-bold">Cidade</label>
            <select id="cidade" className="p-2 border-0 rounded-xl bg-amber-50">
              <option value="">Selecione a cidade</option>
              <option value="Natal">Natal</option>
            </select>
          </div>
  
          <div className="flex flex-col space-y-1">
            <label htmlFor="bairro" className="font-bold">Bairro</label>
            <select id="bairro" className="p-2 border-0 rounded-xl bg-amber-50">
              <option value="">Selecione o bairro</option>
              <option value="LagoaAzul">Lagoa Azul</option>
              <option value="LagoaNova">Lagoa Nova</option>
            </select>
          </div>
  
          <div className="flex flex-col space-y-1">
            <label htmlFor="exame" className="font-bold">Tipo de exame</label>
            <select id="exame" className="p-2 border-0 rounded-xl bg-amber-50">
              <option value="">Tipo de exame</option>
              <option value="RaioX">Raio X</option>
              <option value="Ultrasom">Ultrasom</option>
            </select>
          </div>
          <div className="flex flex-col space-y-1">  
            <div className="flex gap-4">
              <div className="flex flex-col w-full space-y-1">
              <label htmlFor="data" className="font-bold">Data</label>
                <select id="data" className="w-full p-2 border-0 rounded-xl bg-amber-50">
                  <option value="">Selecione a data</option>
                  <option value="2025-10-01">01/10/2025</option>
                  <option value="2025-10-02">02/10/2025</option>
                </select>
              </div>
            
            <div className="flex flex-col w-full space-y-1">
            <label htmlFor="data" className="font-bold">Horário</label>
              <select id="horario" className="w-full p-2 border-0 rounded-xl bg-amber-50">
                  <option value="">Selecione o horário</option>
                  <option value="2025-10-01">10 AM</option>
                  <option value="2025-10-02">15 AM</option>
              </select>
            </div>
            </div>
          </div>
          <div className="flex flex-row gap-4">
          <button
            onClick={navigateToHome}
            className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl text-lg font-medium transition shadow bg-[var(--color-error)] text-[var(--color-surface)] hover:bg-[var(--color-error-dark)] cursor-pointer"
          >
            <X/>
            Cancelar
          </button>
          <button
            // onClick={navigateToAgendarExame}
            className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl text-lg font-medium transition shadow bg-[var(--color-primary)] text-[var(--color-surface)] hover:bg-[var(--color-secondary)] cursor-pointer"
          >
            <CheckIcon/>
            Confirmar
          </button>
          </div>
        </div>
      </div>
    )
}