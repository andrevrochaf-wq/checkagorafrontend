'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { login } from '@/services/authService';
import { useAuth } from '@/contexts/AuthContext';
import Loading from '@/components/Loading';

export default function Login() {
  const router = useRouter();
  const {user, loading, setLoading, setUser } = useAuth();
  const [form, setForm] = useState({ cpf: '', password: '' });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      
      setLoading(true);

      const res = await login(form);
      alert(res.message);

      if (res.user) {
        setUser(res.user);
        setLoading(false);
        console.log(res.user);
        router.push('/');
        console.log('Usuário logado:', res.user);
        console.log('TRUE');
      }
    } catch (error: any) {
      setLoading(false);
      alert(error.response?.data?.message || 'Erro no login');
    }
  };

  if (loading) return <Loading/>;

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-4 py-8" 
         style={{ color: "var(--color-text)" }}>
      <h1 className="text-3xl md:text-4xl text-center font-bold mb-8">
        Login
      </h1>
      <form onSubmit={handleSubmit} className="flex flex-col w-full max-w-md space-y-4">
        <input
          type="text"
          name="cpf" // <-- Aqui
          placeholder="CPF"
          className="p-2 border-0 rounded-xl bg-amber-50"
          onChange={handleChange}
        />
        <input
          type="password"
          name="password" // <-- Aqui
          placeholder="Senha"
          className="p-2 border-0 rounded-xl bg-amber-50"
          onChange={handleChange}
        />
        <div>
          <label>Esqueceu a senha?</label>
          <a href="/recuperarSenha" className="text-blue-500"> Recuperar senha</a>
        </div>
        <button
          type="submit"
          className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl text-base md:text-lg font-medium transition shadow bg-[var(--color-primary)] text-[var(--color-surface)] hover:bg-[var(--color-secondary)] cursor-pointer"
        >
          Entrar
        </button>
        <div className="flex justify-center items-center space-x-1">
          <label>Não possui cadastro?</label>
          <a href="/cadastro" className="text-blue-500"> Cadastre-se</a>
        </div>
      </form>
    </div>
  );
}
