import { ScheduleConsultationCard } from "@/components/ScheduleConsultationCard";

export default function VerificarConsulta() {
    return (
        <div className="flex flex-col items-center pt-16 min-h-screen px-4 py-8">
            <h1 className="text-2xl font-bold mt-4">Verificar consulta ou exame</h1>
            
            {/* Container controlando largura máxima */}
            <div className="flex flex-col w-full max-w-md mt-4 space-y-4 text-[var(--color-text)]">
                <input 
                    type="text" 
                    placeholder="Pesquise sua consulta ou exame aqui" 
                    className="p-2 border-0 rounded-xl bg-amber-50 w-full"
                />
                
                <ScheduleConsultationCard status="pending"/>
                <ScheduleConsultationCard status="rescheduled"/>
                <ScheduleConsultationCard status="canceled"/>
                <ScheduleConsultationCard status="completed"/>
            </div>
        </div>
    )
}
