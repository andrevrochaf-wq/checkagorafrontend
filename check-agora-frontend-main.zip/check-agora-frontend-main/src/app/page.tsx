'use client'

import { useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import { FilePlus, Search } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import Loading from '@/components/Loading';

export default function Home() {
  const router = useRouter();
  const { user, loading, setLoading, setUser } = useAuth();

  useEffect(() => {
    
    // Verifica se o carregamento está completo e o usuário não está logado
    if (loading) {
      return;
    }

    if (!user) {
      // Se o usuário não estiver logado, redireciona para a página de login
      router.push('/login');
    }
  }, [user, loading, router]);

  if (loading) return <Loading/>;
  if (!user) return null; // Garante que a página não será renderizada até redirecionar

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-4 py-8" 
         style={{ color: "var(--color-text)" }}>
      <h1 className="text-3xl md:text-4xl text-center font-bold mb-8">
        Seu tempo vale, a gente cuida
      </h1>

      <div className="w-full max-w-md space-y-4">
        <div className="flex flex-col md:flex-row gap-4">
          <button
            onClick={() => router.push("/agendarConsulta")}
            className="flex items-center justify-center gap-2 w-full md:w-1/2 px-4 py-3 rounded-xl text-base md:text-lg font-medium transition shadow bg-[var(--color-primary)] text-[var(--color-surface)] hover:bg-[var(--color-secondary)] cursor-pointer"
          >
            <FilePlus />
            Agendar Consulta
          </button>

          <button
            onClick={() => router.push("/agendarExame")}
            className="flex items-center justify-center gap-2 w-full md:w-1/2 px-4 py-3 rounded-xl text-base md:text-lg font-medium transition shadow bg-[var(--color-primary)] text-[var(--color-surface)] hover:bg-[var(--color-secondary)] cursor-pointer"
          >
            <FilePlus />
            Agendar Exame
          </button>
        </div>

        <button
          onClick={() => router.push("/verificarConsulta")}
          className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl text-base md:text-lg font-medium transition shadow bg-[var(--color-secondary)] text-[var(--color-surface)] hover:bg-[var(--color-primary)] cursor-pointer"
        >
          <Search />
          Verificar Consulta ou Exame
        </button>
      </div>
    </div>
  );
}
