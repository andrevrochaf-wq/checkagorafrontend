'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { register } from '@/services/authService';
import { useAuth } from '@/contexts/AuthContext';
import Loading from '@/components/Loading';

export default function cadastro() {

  const router = useRouter();

  const { user, loading, setLoading, setUser } = useAuth();

  const [form, setForm] = useState({
    name: '',
    cpf: '',
    password: '',
    confirmPassword: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
  
    const { name, cpf, password, confirmPassword } = form;
  
    // Validação simples no frontend
    if (!name || !cpf || !password || !confirmPassword) {
      alert('Preencha todos os campos.');
      return;
    }
  
    if (!/^\d{11}$/.test(cpf)) {
      alert('CPF deve conter exatamente 11 dígitos numéricos.');
      return;
    }
  
    if (password.length < 3) {
      alert('A senha deve ter pelo menos 6 caracteres.');
      return;
    }
  
    if (password !== confirmPassword) {
      alert('As senhas não coincidem.');
      return;
    }
  
    setLoading(true);
    try {
      const res = await register(form);
      alert(res.message);
      router.push('/login');
    } catch (error: any) {
      alert(error.response?.data?.message || 'Erro no cadastro');
    } finally {
      setLoading(false);
    }
  };
  

  if (loading) return <Loading/>;

  return (
    <div
      className="flex flex-col items-center justify-center min-h-screen px-4 py-8"
      style={{ color: 'var(--color-text)' }}
    >
      <h1 className="text-3xl md:text-4xl text-center font-bold mb-8">
        Cadastro
      </h1>
      <form onSubmit={handleSubmit} className="flex flex-col w-full max-w-md space-y-4">
        <input
          type="text"
          name="name"
          placeholder="Nome"
          className="p-2 border-0 rounded-xl bg-amber-50"
          onChange={handleChange}
        />
        <input
          type="text"
          name="cpf"
          placeholder="CPF"
          className="p-2 border-0 rounded-xl bg-amber-50"
          onChange={handleChange}
        />
        <input
          type="password"
          name="password"
          placeholder="Senha"
          className="p-2 border-0 rounded-xl bg-amber-50"
          onChange={handleChange}
        />
        <input
          type="password"
          name="confirmPassword"
          placeholder="Confirmar senha"
          className="p-2 border-0 rounded-xl bg-amber-50"
          onChange={handleChange}
        />
        <button
          type="submit"
          className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl text-base md:text-lg font-medium transition shadow bg-[var(--color-primary)] text-[var(--color-surface)] hover:bg-[var(--color-secondary)] cursor-pointer"
        >
          Cadastrar
        </button>
        <div className="flex justify-center items-center space-x-1">
          <label>Já possui cadastro?</label>
          <a href="/login" className="text-blue-500"> Login</a>
        </div>
      </form>
    </div>
  );
}
