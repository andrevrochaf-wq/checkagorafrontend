'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { HeaderLink } from '@/components/HeaderLink';
import { User, SquareUser } from 'lucide-react';

export default function ConfigsLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  const isActive = (path: string) =>
    pathname === path ? 'font-bold text-blue-600' : 'text-gray-700';

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      {/* Menu lateral - visível apenas no desktop */}
      <aside className="hidden md:flex w-64 h-full fixed bg-gray-100 p-6 flex-col space-y-4 mt-12">
        <h2 className="text-xl font-bold mb-4">Configurações</h2>
        <HeaderLink icon={<User />} href="/configuracoes/conta">
          Conta
        </HeaderLink>
        <HeaderLink icon={<SquareUser />} href="/configuracoes/perfil">
          Perfil
        </HeaderLink>
      </aside>

      {/* Conteúdo da subpágina */}
      <main className="flex-1 p-6 md:ml-64">{children}</main>
    </div>
  );
}
