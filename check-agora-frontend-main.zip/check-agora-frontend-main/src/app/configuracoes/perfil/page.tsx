export default function Perfil() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-4 py-8" 
         style={{ color: "var(--color-text)" }}>
      <h1 className="text-3xl md:text-4xl text-center font-bold mb-8">
        Perfil
      </h1>
      <p className="text-lg">Aqui você pode gerenciar suas informações de perfil</p>
    </div>
  );
}