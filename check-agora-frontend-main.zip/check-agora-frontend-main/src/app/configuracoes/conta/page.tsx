'use client';

import { useRouter } from 'next/navigation';
import { X } from 'lucide-react';
import { logout } from '@/services/authService'; // ajuste o caminho conforme a organização do projeto
import { useAuth } from '@/contexts/AuthContext';

export default function Conta() {
  const router = useRouter();

  const { setUser } = useAuth();

  const handleLogout = async () => {
    const confirmed = window.confirm("Tem certeza que deseja sair da conta?");
    if (!confirmed) return;

    try {
      await logout();
      setUser(null); // limpa o estado do usuário no contexto
      router.push('/login'); // redireciona para a página de login
    } catch (error) {
      console.error('Erro ao deslogar:', error);
      alert('Não foi possível sair da conta. Tente novamente.');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-4 py-8 gap-4" 
         style={{ color: "var(--color-text)" }}>
      <h1 className="text-3xl md:text-4xl text-center font-bold mb-8">
        Conta
      </h1>
      <p className="text-lg">Aqui você pode gerenciar suas informações de conta</p>
      <button
        onClick={handleLogout}
        className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-lg font-medium transition shadow bg-[var(--color-error)] text-[var(--color-surface)] hover:bg-[var(--color-error-dark)] cursor-pointer"
      >
        <X />
        Sair da conta
      </button>
    </div>
  );
}
